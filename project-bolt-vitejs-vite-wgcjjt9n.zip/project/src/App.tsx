import React, { useState } from 'react';
import { Calendar, DollarSign, FileText, Camera, Download, Plus, CreditCard as Edit, Trash2, LogOut, Zap, Save, X } from 'lucide-react';

// Types
interface User {
  username: string;
  password: string;
  name: string;
  role: string;
}

interface Project {
  id: string;
  name: string;
  client: string;
  priceSold: number;
  expenses: number;
  status: 'active' | 'completed' | 'pending';
  startDate: string;
  endDate?: string;
}

interface CalendarEvent {
  id: string;
  date: string;
  crew: string;
  project: string;
  description: string;
  time: string;
}

interface PhotoReport {
  id: string;
  projectId: string;
  projectName: string;
  date: string;
  beforePhotos: string[];
  duringPhotos: string[];
  afterPhotos: string[];
  notes: string;
}

interface Service {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  unit: string;
}

interface Quote {
  id: string;
  clientName: string;
  clientEmail: string;
  services: { serviceId: string; quantity: number; customPrice?: number }[];
  total: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected';
  date: string;
}

const App: React.FC = () => {
  // Authentication state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });

  // Navigation state
  const [activeModule, setActiveModule] = useState('projects');

  // Data states
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      name: 'Solar Installation - Smith Residence',
      client: 'John Smith',
      priceSold: 25000,
      expenses: 18000,
      status: 'active',
      startDate: '2024-01-15'
    },
    {
      id: '2',
      name: 'Battery System - Johnson Corp',
      client: 'Johnson Corporation',
      priceSold: 45000,
      expenses: 32000,
      status: 'completed',
      startDate: '2024-01-10',
      endDate: '2024-01-25'
    }
  ]);

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      date: '2024-01-20',
      crew: 'Team Alpha',
      project: 'Solar Installation - Smith Residence',
      description: 'Panel installation on roof',
      time: '08:00'
    },
    {
      id: '2',
      date: '2024-01-21',
      crew: 'Team Beta',
      project: 'Battery System - Johnson Corp',
      description: 'Battery system testing',
      time: '10:00'
    }
  ]);

  const [photoReports, _setPhotoReports] = useState<PhotoReport[]>([
    {
      id: '1',
      projectId: '1',
      projectName: 'Solar Installation - Smith Residence',
      date: '2024-01-20',
      beforePhotos: ['https://images.pexels.com/photos/159358/solar-panel-array-power-sun-electricity-159358.jpeg'],
      duringPhotos: ['https://images.pexels.com/photos/2850347/pexels-photo-2850347.jpeg'],
      afterPhotos: ['https://images.pexels.com/photos/433308/pexels-photo-433308.jpeg'],
      notes: 'Installation completed successfully. All panels properly mounted and connected.'
    }
  ]);

  const [services, _setServices] = useState<Service[]>([
    { id: '1', name: 'Solar Panel Installation', description: 'Complete solar panel system installation', basePrice: 3000, unit: 'kW' },
    { id: '2', name: 'Battery Storage System', description: 'Energy storage solution installation', basePrice: 8000, unit: 'kWh' },
    { id: '3', name: 'Electrical Wiring', description: 'Professional electrical wiring services', basePrice: 150, unit: 'hour' },
    { id: '4', name: 'System Maintenance', description: 'Annual maintenance and inspection', basePrice: 500, unit: 'visit' }
  ]);

  const [quotes, setQuotes] = useState<Quote[]>([
    {
      id: '1',
      clientName: 'Sarah Wilson',
      clientEmail: 'sarah@email.com',
      services: [{ serviceId: '1', quantity: 5 }, { serviceId: '2', quantity: 10 }],
      total: 95000,
      status: 'sent',
      date: '2024-01-18'
    }
  ]);

  // Form states
  const [showProjectForm, setShowProjectForm] = useState(false);
  const [showEventForm, setShowEventForm] = useState(false);
  const [showQuoteForm, setShowQuoteForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);

  // Users database
  const users: User[] = [
    { username: 'admin', password: 'admin123', name: 'Administrator', role: 'admin' },
    { username: 'juan.perez', password: 'juan123', name: 'Juan Pérez', role: 'manager' }
  ];

  // Authentication functions
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.username === loginForm.username && u.password === loginForm.password);
    if (user) {
      setCurrentUser(user);
      setIsLoggedIn(true);
      setLoginForm({ username: '', password: '' });
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setActiveModule('projects');
  };

  // Project functions
  const handleSaveProject = (projectData: Omit<Project, 'id'>) => {
    if (editingProject) {
      setProjects(projects.map(p => p.id === editingProject.id ? { ...projectData, id: editingProject.id } : p));
      setEditingProject(null);
    } else {
      const newProject = { ...projectData, id: Date.now().toString() };
      setProjects([...projects, newProject]);
    }
    setShowProjectForm(false);
  };

  const handleDeleteProject = (id: string) => {
    if (confirm('Are you sure you want to delete this project?')) {
      setProjects(projects.filter(p => p.id !== id));
    }
  };

  // Calendar functions
  const handleSaveEvent = (eventData: Omit<CalendarEvent, 'id'>) => {
    if (editingEvent) {
      setCalendarEvents(calendarEvents.map(e => e.id === editingEvent.id ? { ...eventData, id: editingEvent.id } : e));
      setEditingEvent(null);
    } else {
      const newEvent = { ...eventData, id: Date.now().toString() };
      setCalendarEvents([...calendarEvents, newEvent]);
    }
    setShowEventForm(false);
  };

  const handleDeleteEvent = (id: string) => {
    if (confirm('Are you sure you want to delete this event?')) {
      setCalendarEvents(calendarEvents.filter(e => e.id !== id));
    }
  };

  // Quote functions
  const handleSaveQuote = (quoteData: Omit<Quote, 'id'>) => {
    const newQuote = { ...quoteData, id: Date.now().toString() };
    setQuotes([...quotes, newQuote]);
    setShowQuoteForm(false);
  };

  const generatePDF = (report: PhotoReport) => {
    alert(`PDF generated for ${report.projectName} - ${report.date}`);
  };

  // Login Screen
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
        <div className="bg-gray-800 p-8 rounded-lg shadow-xl w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Zap className="w-12 h-12 text-orange-500 mr-2" />
              <h1 className="text-3xl font-bold text-white">ENERGY</h1>
            </div>
            <p className="text-gray-400">Energy Management System</p>
          </div>
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Username</label>
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>
            
            <button
              type="submit"
              className="w-full bg-orange-500 text-white py-2 px-4 rounded-md hover:bg-orange-600 transition-colors"
            >
              Login
            </button>
          </form>
          
          <div className="mt-6 text-sm text-gray-400">
            <p>Demo credentials:</p>
            <p>admin / admin123</p>
            <p>juan.perez / juan123</p>
          </div>
        </div>
      </div>
    );
  }

  // Main App
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Zap className="w-8 h-8 text-orange-500 mr-3" />
            <h1 className="text-2xl font-bold">ENERGY</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">Welcome, {currentUser?.name}</span>
            <button
              onClick={handleLogout}
              className="flex items-center text-gray-300 hover:text-white transition-colors"
            >
              <LogOut className="w-4 h-4 mr-1" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-gray-800 min-h-screen p-4">
          <div className="space-y-2">
            {[
              { id: 'projects', label: 'Projects', icon: DollarSign },
              { id: 'calendar', label: 'Calendar', icon: Calendar },
              { id: 'photos', label: 'Photo Reports', icon: Camera },
              { id: 'quotes', label: 'Quotes', icon: FileText }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveModule(id)}
                className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors ${
                  activeModule === id 
                    ? 'bg-orange-500 text-white' 
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                <Icon className="w-5 h-5 mr-3" />
                {label}
              </button>
            ))}
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Projects Module */}
          {activeModule === 'projects' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold">Projects & Finances</h2>
                <button
                  onClick={() => setShowProjectForm(true)}
                  className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Project
                </button>
              </div>

              <div className="grid gap-6">
                {projects.map(project => {
                  const profit = project.priceSold - project.expenses;
                  const profitMargin = ((profit / project.priceSold) * 100).toFixed(1);
                  
                  return (
                    <div key={project.id} className="bg-gray-800 p-6 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-semibold">{project.name}</h3>
                          <p className="text-gray-400">Client: {project.client}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            project.status === 'completed' ? 'bg-green-600' :
                            project.status === 'active' ? 'bg-blue-600' : 'bg-yellow-600'
                          }`}>
                            {project.status}
                          </span>
                          <button
                            onClick={() => {
                              setEditingProject(project);
                              setShowProjectForm(true);
                            }}
                            className="text-gray-400 hover:text-white"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProject(project.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-4 gap-4">
                        <div className="bg-gray-700 p-4 rounded">
                          <p className="text-gray-400 text-sm">Price Sold</p>
                          <p className="text-2xl font-bold text-green-400">${project.priceSold.toLocaleString()}</p>
                        </div>
                        <div className="bg-gray-700 p-4 rounded">
                          <p className="text-gray-400 text-sm">Expenses</p>
                          <p className="text-2xl font-bold text-red-400">${project.expenses.toLocaleString()}</p>
                        </div>
                        <div className="bg-gray-700 p-4 rounded">
                          <p className="text-gray-400 text-sm">Profit</p>
                          <p className={`text-2xl font-bold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            ${profit.toLocaleString()}
                          </p>
                        </div>
                        <div className="bg-gray-700 p-4 rounded">
                          <p className="text-gray-400 text-sm">Margin</p>
                          <p className={`text-2xl font-bold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {profitMargin}%
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Calendar Module */}
          {activeModule === 'calendar' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold">Calendar & Crew Assignments</h2>
                <button
                  onClick={() => setShowEventForm(true)}
                  className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Assignment
                </button>
              </div>

              <div className="grid gap-4">
                {calendarEvents.map(event => (
                  <div key={event.id} className="bg-gray-800 p-6 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-xl font-semibold">{event.project}</h3>
                        <p className="text-gray-400">Crew: {event.crew}</p>
                        <p className="text-gray-400">Date: {event.date} at {event.time}</p>
                        <p className="text-gray-300 mt-2">{event.description}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setEditingEvent(event);
                            setShowEventForm(true);
                          }}
                          className="text-gray-400 hover:text-white"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteEvent(event.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Photo Reports Module */}
          {activeModule === 'photos' && (
            <div>
              <h2 className="text-3xl font-bold mb-6">Photo Reports</h2>
              
              <div className="grid gap-6">
                {photoReports.map(report => (
                  <div key={report.id} className="bg-gray-800 p-6 rounded-lg">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold">{report.projectName}</h3>
                        <p className="text-gray-400">Date: {report.date}</p>
                      </div>
                      <button
                        onClick={() => generatePDF(report)}
                        className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Generate PDF
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <h4 className="font-semibold mb-2 text-orange-400">Before</h4>
                        <div className="grid gap-2">
                          {report.beforePhotos.map((photo, index) => (
                            <img key={index} src={photo} alt="Before" className="w-full h-32 object-cover rounded" />
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 text-orange-400">During</h4>
                        <div className="grid gap-2">
                          {report.duringPhotos.map((photo, index) => (
                            <img key={index} src={photo} alt="During" className="w-full h-32 object-cover rounded" />
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 text-orange-400">After</h4>
                        <div className="grid gap-2">
                          {report.afterPhotos.map((photo, index) => (
                            <img key={index} src={photo} alt="After" className="w-full h-32 object-cover rounded" />
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-700 p-4 rounded">
                      <h4 className="font-semibold mb-2">Notes</h4>
                      <p className="text-gray-300">{report.notes}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quotes Module */}
          {activeModule === 'quotes' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-3xl font-bold">Quotes & Service Catalog</h2>
                <button
                  onClick={() => setShowQuoteForm(true)}
                  className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors flex items-center"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Quote
                </button>
              </div>

              {/* Service Catalog */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">Service Catalog</h3>
                <div className="grid grid-cols-2 gap-4">
                  {services.map(service => (
                    <div key={service.id} className="bg-gray-800 p-4 rounded-lg">
                      <h4 className="font-semibold">{service.name}</h4>
                      <p className="text-gray-400 text-sm">{service.description}</p>
                      <p className="text-orange-400 font-bold">${service.basePrice} per {service.unit}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quotes List */}
              <div>
                <h3 className="text-xl font-semibold mb-4">Recent Quotes</h3>
                <div className="grid gap-4">
                  {quotes.map(quote => (
                    <div key={quote.id} className="bg-gray-800 p-6 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-lg font-semibold">{quote.clientName}</h4>
                          <p className="text-gray-400">{quote.clientEmail}</p>
                          <p className="text-gray-400">Date: {quote.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-400">${quote.total.toLocaleString()}</p>
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            quote.status === 'accepted' ? 'bg-green-600' :
                            quote.status === 'sent' ? 'bg-blue-600' :
                            quote.status === 'rejected' ? 'bg-red-600' : 'bg-yellow-600'
                          }`}>
                            {quote.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Project Form Modal */}
      {showProjectForm && (
        <ProjectForm
          project={editingProject}
          onSave={handleSaveProject}
          onCancel={() => {
            setShowProjectForm(false);
            setEditingProject(null);
          }}
        />
      )}

      {/* Event Form Modal */}
      {showEventForm && (
        <EventForm
          event={editingEvent}
          projects={projects}
          onSave={handleSaveEvent}
          onCancel={() => {
            setShowEventForm(false);
            setEditingEvent(null);
          }}
        />
      )}

      {/* Quote Form Modal */}
      {showQuoteForm && (
        <QuoteForm
          services={services}
          onSave={handleSaveQuote}
          onCancel={() => setShowQuoteForm(false)}
        />
      )}
    </div>
  );
};

// Project Form Component
const ProjectForm: React.FC<{
  project: Project | null;
  onSave: (project: Omit<Project, 'id'>) => void;
  onCancel: () => void;
}> = ({ project, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    name: project?.name || '',
    client: project?.client || '',
    priceSold: project?.priceSold || 0,
    expenses: project?.expenses || 0,
    status: project?.status || 'pending' as const,
    startDate: project?.startDate || '',
    endDate: project?.endDate || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 p-6 rounded-lg w-full max-w-md">
        <h3 className="text-xl font-bold mb-4">{project ? 'Edit Project' : 'New Project'}</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Project Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Client</label>
            <input
              type="text"
              value={formData.client}
              onChange={(e) => setFormData({ ...formData, client: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Price Sold</label>
              <input
                type="number"
                value={formData.priceSold}
                onChange={(e) => setFormData({ ...formData, priceSold: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Expenses</label>
              <input
                type="number"
                value={formData.expenses}
                onChange={(e) => setFormData({ ...formData, expenses: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
                required
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
            >
              <option value="pending">Pending</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Start Date</label>
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">End Date</label>
              <input
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              />
            </div>
          </div>
          
          <div className="flex space-x-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition-colors flex items-center justify-center"
            >
              <Save className="w-4 h-4 mr-2" />
              Save
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700 transition-colors flex items-center justify-center"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Event Form Component
const EventForm: React.FC<{
  event: CalendarEvent | null;
  projects: Project[];
  onSave: (event: Omit<CalendarEvent, 'id'>) => void;
  onCancel: () => void;
}> = ({ event, projects, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    date: event?.date || '',
    crew: event?.crew || '',
    project: event?.project || '',
    description: event?.description || '',
    time: event?.time || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 p-6 rounded-lg w-full max-w-md">
        <h3 className="text-xl font-bold mb-4">{event ? 'Edit Assignment' : 'New Assignment'}</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Date</label>
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Time</label>
            <input
              type="time"
              value={formData.time}
              onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Crew</label>
            <select
              value={formData.crew}
              onChange={(e) => setFormData({ ...formData, crew: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            >
              <option value="">Select Crew</option>
              <option value="Team Alpha">Team Alpha</option>
              <option value="Team Beta">Team Beta</option>
              <option value="Team Gamma">Team Gamma</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Project</label>
            <select
              value={formData.project}
              onChange={(e) => setFormData({ ...formData, project: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            >
              <option value="">Select Project</option>
              {projects.map(project => (
                <option key={project.id} value={project.name}>{project.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
              rows={3}
              required
            />
          </div>
          
          <div className="flex space-x-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition-colors flex items-center justify-center"
            >
              <Save className="w-4 h-4 mr-2" />
              Save
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700 transition-colors flex items-center justify-center"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Quote Form Component
const QuoteForm: React.FC<{
  services: Service[];
  onSave: (quote: Omit<Quote, 'id'>) => void;
  onCancel: () => void;
}> = ({ services, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    clientName: '',
    clientEmail: '',
    services: [] as { serviceId: string; quantity: number }[],
    status: 'draft' as const
  });

  const addService = () => {
    setFormData({
      ...formData,
      services: [...formData.services, { serviceId: '', quantity: 1 }]
    });
  };

  const updateService = (index: number, field: string, value: any) => {
    const updatedServices = [...formData.services];
    updatedServices[index] = { ...updatedServices[index], [field]: value };
    setFormData({ ...formData, services: updatedServices });
  };

  const removeService = (index: number) => {
    setFormData({
      ...formData,
      services: formData.services.filter((_, i) => i !== index)
    });
  };

  const calculateTotal = () => {
    return formData.services.reduce((total, item) => {
      const service = services.find(s => s.id === item.serviceId);
      return total + (service ? service.basePrice * item.quantity : 0);
    }, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      total: calculateTotal(),
      date: new Date().toISOString().split('T')[0]
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 p-6 rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h3 className="text-xl font-bold mb-4">New Quote</h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Client Name</label>
              <input
                type="text"
                value={formData.clientName}
                onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Client Email</label>
              <input
                type="email"
                value={formData.clientEmail}
                onChange={(e) => setFormData({ ...formData, clientEmail: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white"
                required
              />
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-300">Services</label>
              <button
                type="button"
                onClick={addService}
                className="bg-orange-500 text-white px-3 py-1 rounded text-sm hover:bg-orange-600 transition-colors"
              >
                Add Service
              </button>
            </div>
            
            <div className="space-y-2">
              {formData.services.map((item, index) => (
                <div key={index} className="flex items-center space-x-2 bg-gray-700 p-3 rounded">
                  <select
                    value={item.serviceId}
                    onChange={(e) => updateService(index, 'serviceId', e.target.value)}
                    className="flex-1 px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                    required
                  >
                    <option value="">Select Service</option>
                    {services.map(service => (
                      <option key={service.id} value={service.id}>
                        {service.name} - ${service.basePrice}/{service.unit}
                      </option>
                    ))}
                  </select>
                  
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateService(index, 'quantity', Number(e.target.value))}
                    className="w-20 px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                    min="1"
                    required
                  />
                  
                  <button
                    type="button"
                    onClick={() => removeService(index)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-gray-700 p-4 rounded">
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold">Total:</span>
              <span className="text-2xl font-bold text-green-400">${calculateTotal().toLocaleString()}</span>
            </div>
          </div>
          
          <div className="flex space-x-4 pt-4">
            <button
              type="submit"
              className="flex-1 bg-orange-500 text-white py-2 px-4 rounded hover:bg-orange-600 transition-colors flex items-center justify-center"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Quote
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-700 transition-colors flex items-center justify-center"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default App;